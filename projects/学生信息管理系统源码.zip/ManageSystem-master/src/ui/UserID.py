'''
@coding=UTF-8
@auther:Yan Chen, Fei JianLin, Yang Cheng, Tang YuHao
@time:2020-06
@ui:Global userID
'''

global userID

def setID(num):
    global userID
    userID = num

def getID():
    return  userID