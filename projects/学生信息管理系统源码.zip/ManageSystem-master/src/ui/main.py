'''
@coding=UTF-8
@auther:Yan Chen, Fei JianLin, Yang Cheng, Tang YuHao
@time:2020-06
@ui:Main
'''

from src.ui.Login import Login

if __name__ == '__main__':
    Login()