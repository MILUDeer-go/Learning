__all__ = ['Login', 'HomeRoot', 'ViewInfoRoot', 'ModifyRoot', 'HomeStu', 'ViewInfoStu', 'ViewScoreStu', 'main']
from src.ui import Login
from src.ui import HomeRoot
from src.ui import ViewInfoRoot
from src.ui import ModifyRoot
from src.ui import HomeStu
from src.ui import ViewInfoStu
from src.ui import ViewScoreStu
from src.ui import main